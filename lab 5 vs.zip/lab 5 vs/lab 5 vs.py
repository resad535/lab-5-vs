# Birinci ədədi massiv yaradırıq
ededi_massiv = [1, 5, 10, 15, 8, 3, 12, 7, 20, 4]

# Birinci faylı yaradırıq və massivi fayla yazırıq
with open("massiv.txt", "w") as f:
    for eded in ededi_massiv:
        f.write(str(eded) + "\n")

# İkinci faylı yaradırıq və 9-dan böyük ədədləri yeni fayla yazırıq
with open("yenifayl.txt", "w") as yeni_fayl:
    cem = 0
    for eded in ededi_massiv:
        if eded > 9:
            yeni_fayl.write(str(eded) + "\n")
            cem += eded

# Cəmi ekrana çap edirik
print("Cəm:", cem)